package com.springboot.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SpringbootFirstappApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootFirstappApplication.class, args);
	}
}

@RestController
@RequestMapping("api")
class MyController {
	@GetMapping("/init1")
	public String init1() {
		return "This is init1!";
	}

	@GetMapping("/init2")
	public String init2() {
		return "This is init2!";
	}

}